import discord
from datetime import datetime, timezone

# Status emoji mapping
STATUS_EMOJI = {
    "IN_PLAY": "🟢",
    "PAUSED": "⏸️",
    "FINISHED": "✅",
    "SCHEDULED": "📅",
    "POSTPONED": "⚠️",
    "CANCELLED": "❌",
    "TIMED": "🕐",
}

LEAGUE_EMOJI = {
    "PL": "🏴󠁧󠁢󠁥󠁮󠁧󠁿",
    "BL1": "🇩🇪",
    "SA": "🇮🇹",
    "PD": "🇪🇸",
    "FL1": "🇫🇷",
    "CL": "⭐",
    "EL": "🟠",
}


def _score_str(match: dict) -> str:
    ft = match.get("score", {}).get("fullTime", {})
    ht = match.get("score", {}).get("halfTime", {})
    home = ft.get("home")
    away = ft.get("away")
    if home is None:
        return "vs"
    score = f"**{home} - {away}**"
    if ht.get("home") is not None and match.get("status") in ("IN_PLAY", "PAUSED", "FINISHED"):
        score += f" *(HT: {ht['home']}-{ht['away']})*"
    return score


def build_match_embed(match: dict) -> discord.Embed:
    home = match.get("homeTeam", {}).get("name", "Home")
    away = match.get("awayTeam", {}).get("name", "Away")
    status = match.get("status", "SCHEDULED")
    competition = match.get("competition", {})
    league_code = competition.get("code", "")
    league_name = competition.get("name", "Match")
    emoji = LEAGUE_EMOJI.get(league_code, "⚽")
    status_emoji = STATUS_EMOJI.get(status, "⚽")

    color_map = {
        "IN_PLAY": discord.Color.green(),
        "PAUSED": discord.Color.yellow(),
        "FINISHED": discord.Color.greyple(),
        "SCHEDULED": discord.Color.blue(),
    }
    color = color_map.get(status, discord.Color.blurple())

    embed = discord.Embed(
        title=f"{emoji} {home} vs {away}",
        description=_score_str(match),
        color=color,
    )
    embed.set_author(name=f"{status_emoji} {league_name}")

    # Minute
    minute = match.get("minute")
    if minute and status == "IN_PLAY":
        embed.add_field(name="⏱️ Minute", value=f"{minute}'", inline=True)

    # Matchday
    matchday = match.get("matchday")
    if matchday:
        embed.add_field(name="📆 Matchday", value=str(matchday), inline=True)

    # Venue / date
    utc_date = match.get("utcDate")
    if utc_date:
        dt = datetime.fromisoformat(utc_date.replace("Z", "+00:00"))
        embed.add_field(name="🗓️ Date", value=discord.utils.format_dt(dt, style="F"), inline=False)

    embed.set_footer(text=f"Match ID: {match.get('id', 'N/A')} • football-data.org")
    return embed


def build_standings_embed(table: list[dict], league_name: str, page: int = 0) -> discord.Embed:
    embed = discord.Embed(title=f"🏆 {league_name} Standings", color=discord.Color.gold())
    start = page * 10
    chunk = table[start:start + 10]

    rows = []
    for row in chunk:
        pos = row.get("position", "?")
        team = row.get("team", {}).get("shortName") or row.get("team", {}).get("name", "Unknown")
        pts = row.get("points", 0)
        played = row.get("playedGames", 0)
        gd = row.get("goalDifference", 0)
        gd_str = f"+{gd}" if gd > 0 else str(gd)
        rows.append(f"`{pos:>2}.` **{team:<22}** `{played}GP {pts}pts GD:{gd_str}`")

    embed.description = "\n".join(rows)
    embed.set_footer(text=f"Page {page+1} • Updated live")
    return embed


def build_player_embed(player: dict, team_name: str = "") -> discord.Embed:
    name = player.get("name", "Unknown Player")
    position = player.get("position", "N/A")
    nationality = player.get("nationality", "N/A")
    dob = player.get("dateOfBirth", "")

    embed = discord.Embed(
        title=f"👤 {name}",
        color=discord.Color.blue(),
    )
    embed.add_field(name="Position", value=position, inline=True)
    embed.add_field(name="Nationality", value=nationality, inline=True)
    if team_name:
        embed.add_field(name="Club", value=team_name, inline=True)
    if dob:
        embed.add_field(name="Date of Birth", value=dob[:10], inline=True)

    shirt = player.get("shirtNumber")
    if shirt:
        embed.add_field(name="Shirt #", value=str(shirt), inline=True)

    embed.set_footer(text="football-data.org")
    return embed


def build_alert_embed(match: dict, alert_type: str) -> discord.Embed:
    home = match.get("homeTeam", {}).get("name", "Home")
    away = match.get("awayTeam", {}).get("name", "Away")
    score = match.get("score", {}).get("fullTime", {})

    messages = {
        "goal": f"⚽ **GOAL!** {home} {score.get('home', 0)}-{score.get('away', 0)} {away}",
        "kickoff": f"🟢 **KICK OFF!** {home} vs {away} has started!",
        "fulltime": f"✅ **FULL TIME!** {home} {score.get('home', 0)}-{score.get('away', 0)} {away}",
        "halftime": f"⏸️ **HALF TIME!** {home} {score.get('home', 0)}-{score.get('away', 0)} {away}",
    }

    colors = {
        "goal": discord.Color.green(),
        "kickoff": discord.Color.brand_green(),
        "fulltime": discord.Color.red(),
        "halftime": discord.Color.yellow(),
    }

    embed = discord.Embed(
        description=messages.get(alert_type, f"📣 Update: {home} vs {away}"),
        color=colors.get(alert_type, discord.Color.blurple()),
        timestamp=datetime.now(timezone.utc),
    )
    competition = match.get("competition", {}).get("name", "")
    if competition:
        embed.set_footer(text=competition)
    return embed


def build_scorers_embed(scorers: list[dict], league_name: str) -> discord.Embed:
    embed = discord.Embed(title=f"🥅 {league_name} Top Scorers", color=discord.Color.orange())
    rows = []
    for i, s in enumerate(scorers[:10], 1):
        player = s.get("player", {}).get("name", "Unknown")
        team = s.get("team", {}).get("shortName", "")
        goals = s.get("goals", 0)
        assists = s.get("assists", 0)
        rows.append(f"`{i:>2}.` **{player}** ({team}) — `{goals}G {assists}A`")
    embed.description = "\n".join(rows)
    return embed


def build_fpl_team_embed(entry: dict, picks: dict, gw: int) -> discord.Embed:
    name = entry.get("name", "FPL Team")
    player_name = f"{entry.get('player_first_name', '')} {entry.get('player_last_name', '')}".strip()
    total_points = entry.get("summary_overall_points", 0)
    overall_rank = entry.get("summary_overall_rank", 0)
    gw_points = picks.get("entry_history", {}).get("points", 0) if picks else 0

    embed = discord.Embed(
        title=f"🏅 {name}",
        description=f"Manager: **{player_name}**",
        color=discord.Color.purple(),
    )
    embed.add_field(name="GW Points", value=str(gw_points), inline=True)
    embed.add_field(name="Total Points", value=str(total_points), inline=True)
    embed.add_field(name="Overall Rank", value=f"#{overall_rank:,}", inline=True)
    embed.set_footer(text=f"Gameweek {gw} • Fantasy Premier League")
    return embed
